package busticketbookingmanagementsystem;

/**
 *
 * @author Saurabh Pardeshi
 * THANKS : )
 *  
 */
public class getData {
    
    public static Integer number;
    public static String username;
    
}
