package busticketbookingmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Saurabh Pardeshi
 */
public class database {
    
    public static Connection connectDb(){
        
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
                                //                      DATABASE LINK, USERNAME, PASSWORD ROOT IS THE DEFAULT USERNAME 
            Connection connect = DriverManager.getConnection("jdbc:mysql://www.papademas.net:3307/510fp?autoReconnect=true&useSSL=false", "fp510", "510"); 
            return connect;
        }catch(Exception e){e.printStackTrace();}
        return null;
    }
}